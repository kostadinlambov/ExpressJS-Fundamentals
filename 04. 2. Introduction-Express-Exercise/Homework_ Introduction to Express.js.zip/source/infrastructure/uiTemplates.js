module.exports = {
    errorMessage: () => 
        '<div id="errBox"><h2 id="errMsg">Please fill all fields</h2></div>',
    successMessage: () => 
        '<div id="succssesBox"><h2 id="succssesMsg">Meme Added</h2></div>' 
};