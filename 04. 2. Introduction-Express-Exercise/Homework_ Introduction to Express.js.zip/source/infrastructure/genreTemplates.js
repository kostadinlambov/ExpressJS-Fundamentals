module.exports = {
    viewAll: (title, index) =>
        ` <div class="genreClass"><h3>${index}. ${title}</h3></div>`
};